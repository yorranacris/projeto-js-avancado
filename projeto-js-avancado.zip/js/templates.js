import { getData } from "./storage.js";

export function loadTemplate(page) {
  if (page === "home") renderHome();
}

function renderHome() {
  const container = document.getElementById("dynamic-content");
  if (!container) return;

  const produtos = getData("produtos");

  if (produtos.length === 0) {
    container.innerHTML = "<p>Nenhum produto cadastrado ainda.</p>";
  } else {
    container.innerHTML = produtos.map(p => `
      <div class="card">
        <h3>${p.nome}</h3>
        <p>Preço: R$ ${p.preco}</p>
      </div>
    `).join("");
  }
}