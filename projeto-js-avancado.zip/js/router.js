import { loadTemplate } from "./templates.js";
import { validateForm } from "./formValidation.js";

export function initRouter() {
  window.addEventListener("hashchange", () => loadPage());
  loadPage();
}

async function loadPage() {
  const hash = window.location.hash.replace("#", "") || "home";
  const container = document.getElementById("app");

  try {
    const response = await fetch(`./pages/${hash}.html`);
    const html = await response.text();
    container.innerHTML = html;

    loadTemplate(hash);

    if (hash === "contact") {
      validateForm("contactForm");
    }

  } catch (error) {
    container.innerHTML = `<h2>Página não encontrada 😕</h2>`;
  }
}