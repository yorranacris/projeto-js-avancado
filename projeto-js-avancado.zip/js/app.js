import { initRouter } from "./router.js";

document.addEventListener("DOMContentLoaded", () => {
  initRouter();
});