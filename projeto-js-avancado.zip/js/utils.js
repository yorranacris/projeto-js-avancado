// Funções auxiliares podem ser adicionadas aqui futuramente.
