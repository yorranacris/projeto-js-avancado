import { saveData, getData } from "./storage.js";

export function validateForm(formId) {
  const form = document.getElementById(formId);

  form.addEventListener("submit", (event) => {
    event.preventDefault();

    const nome = form.querySelector("#name").value.trim();
    const preco = form.querySelector("#price").value.trim();

    if (nome.length < 3) {
      alert("O nome deve ter pelo menos 3 caracteres!");
      return;
    }

    if (isNaN(preco) || preco <= 0) {
      alert("O preço deve ser um número positivo!");
      return;
    }

    const produtos = getData("produtos");
    produtos.push({ nome, preco });
    saveData("produtos", produtos);

    alert("Produto cadastrado com sucesso!");
    form.reset();
  });
}